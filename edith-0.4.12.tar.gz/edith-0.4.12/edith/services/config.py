import json
import os
from pathlib import Path
from typing import List

from edith.models.server import ServerInfo, FolderInfo

CONFIG_DIR = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / "edith"
SERVERS_FILE = CONFIG_DIR / "servers.json"


class ConfigService:
    """Load and save server/folder configurations to ~/.config/edith/servers.json."""

    _servers_file_override = None  # set via set_servers_file()

    @classmethod
    def set_servers_file(cls, path: str):
        """Use a custom servers file instead of the default."""
        cls._servers_file_override = Path(path)

    @classmethod
    def _servers_file(cls) -> Path:
        return cls._servers_file_override or SERVERS_FILE

    # --- Internal helpers ---

    @classmethod
    def _load_raw(cls) -> dict:
        path = cls._servers_file()
        if not path.exists():
            return {}
        try:
            return json.loads(path.read_text())
        except (json.JSONDecodeError, KeyError):
            return {}

    @classmethod
    def _save(cls, servers: List[ServerInfo], folders: List[FolderInfo]):
        path = cls._servers_file()
        path.parent.mkdir(parents=True, exist_ok=True)
        data = cls._load_raw()
        data["servers"] = [s.to_dict() for s in servers]
        data["folders"] = [f.to_dict() for f in folders]
        path.write_text(json.dumps(data, indent=2))

    # --- Server operations ---

    @staticmethod
    def load_servers() -> List[ServerInfo]:
        data = ConfigService._load_raw()
        return [ServerInfo.from_dict(s) for s in data.get("servers", [])]

    @staticmethod
    def save_servers(servers: List[ServerInfo]):
        folders = ConfigService.load_folders()
        ConfigService._save(servers, folders)

    @staticmethod
    def add_server(server: ServerInfo) -> List[ServerInfo]:
        servers = ConfigService.load_servers()
        servers.append(server)
        ConfigService.save_servers(servers)
        return servers

    @staticmethod
    def update_server(server: ServerInfo) -> List[ServerInfo]:
        servers = ConfigService.load_servers()
        for i, s in enumerate(servers):
            if s.id == server.id:
                servers[i] = server
                break
        ConfigService.save_servers(servers)
        return servers

    @staticmethod
    def delete_server(server_id: str) -> List[ServerInfo]:
        servers = ConfigService.load_servers()
        servers = [s for s in servers if s.id != server_id]
        ConfigService.save_servers(servers)
        return servers

    # --- Folder operations ---

    @staticmethod
    def load_folders() -> List[FolderInfo]:
        data = ConfigService._load_raw()
        return [FolderInfo.from_dict(f) for f in data.get("folders", [])]

    @staticmethod
    def save_folders(folders: List[FolderInfo]):
        servers = ConfigService.load_servers()
        ConfigService._save(servers, folders)

    @staticmethod
    def save_all(servers: List[ServerInfo], folders: List[FolderInfo]):
        ConfigService._save(servers, folders)

    @staticmethod
    def add_folder(folder: FolderInfo) -> List[FolderInfo]:
        folders = ConfigService.load_folders()
        folders.append(folder)
        ConfigService.save_folders(folders)
        return folders

    @staticmethod
    def update_folder(folder: FolderInfo) -> List[FolderInfo]:
        folders = ConfigService.load_folders()
        for i, f in enumerate(folders):
            if f.id == folder.id:
                folders[i] = folder
                break
        ConfigService.save_folders(folders)
        return folders

    @staticmethod
    def delete_folder(folder_id: str) -> List[FolderInfo]:
        folders = ConfigService.load_folders()
        folders = [f for f in folders if f.id != folder_id]
        ConfigService.save_folders(folders)
        return folders

    @staticmethod
    def reorder_folders(ordered_ids: list):
        """Reorder the folders list to match the given ID order and save."""
        folders = ConfigService.load_folders()
        id_to_folder = {f.id: f for f in folders}
        reordered = [id_to_folder[fid] for fid in ordered_ids if fid in id_to_folder]
        # Append any folders not in the list (shouldn't happen, but be safe)
        seen = set(ordered_ids)
        for f in folders:
            if f.id not in seen:
                reordered.append(f)
        ConfigService.save_folders(reordered)
        return reordered

    @staticmethod
    def move_server_to_folder(server_id: str, folder_id: str):
        servers = ConfigService.load_servers()
        for s in servers:
            if s.id == server_id:
                s.folder_id = folder_id
                break
        ConfigService.save_servers(servers)

    # --- Recents ---

    RECENTS_MAX = 5

    @staticmethod
    def get_recents(server_id: str) -> list:
        data = ConfigService._load_raw()
        return data.get("recents", {}).get(server_id, [])

    @staticmethod
    def push_recent(server_id: str, path: str):
        data = ConfigService._load_raw()
        recents = data.get("recents", {})
        paths = [p for p in recents.get(server_id, []) if p != path]
        paths.insert(0, path)
        recents[server_id] = paths[:ConfigService.RECENTS_MAX]
        data["recents"] = recents
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        SERVERS_FILE.write_text(json.dumps(data, indent=2))

    @staticmethod
    def delete_recent(server_id: str, path: str):
        data = ConfigService._load_raw()
        recents = data.get("recents", {})
        recents[server_id] = [p for p in recents.get(server_id, []) if p != path]
        data["recents"] = recents
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        SERVERS_FILE.write_text(json.dumps(data, indent=2))

    # --- Pins ---

    @staticmethod
    def get_pins(server_id: str) -> list:
        data = ConfigService._load_raw()
        return data.get("pins", {}).get(server_id, [])

    @staticmethod
    def add_pin(server_id: str, path: str, is_dir: bool):
        data = ConfigService._load_raw()
        pins = data.get("pins", {})
        entries = pins.get(server_id, [])
        if not any(e["path"] == path for e in entries):
            entries.append({"path": path, "is_dir": is_dir})
        pins[server_id] = entries
        data["pins"] = pins
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        SERVERS_FILE.write_text(json.dumps(data, indent=2))

    @staticmethod
    def delete_pin(server_id: str, path: str):
        data = ConfigService._load_raw()
        pins = data.get("pins", {})
        pins[server_id] = [e for e in pins.get(server_id, []) if e["path"] != path]
        data["pins"] = pins
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        SERVERS_FILE.write_text(json.dumps(data, indent=2))

    # --- Pinned servers ---

    @staticmethod
    def get_pinned_servers() -> list:
        data = ConfigService._load_raw()
        return data.get("pinned_servers", [])

    @staticmethod
    def is_server_pinned(server_id: str) -> bool:
        return server_id in ConfigService.get_pinned_servers()

    @staticmethod
    def toggle_server_pin(server_id: str):
        data = ConfigService._load_raw()
        pins = data.get("pinned_servers", [])
        if server_id in pins:
            pins.remove(server_id)
        else:
            pins.append(server_id)
        data["pinned_servers"] = pins
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        SERVERS_FILE.write_text(json.dumps(data, indent=2))

    # --- Preferences ---

    @staticmethod
    def get_preference(key: str, default=None):
        data = ConfigService._load_raw()
        return data.get("preferences", {}).get(key, default)

    @staticmethod
    def set_preference(key: str, value):
        data = ConfigService._load_raw()
        prefs = data.get("preferences", {})
        prefs[key] = value
        data["preferences"] = prefs
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        SERVERS_FILE.write_text(json.dumps(data, indent=2))
